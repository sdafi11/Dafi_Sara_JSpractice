﻿using System;

namespace Dafi_Sara_CE01
{
    class Program
    {
        static void Main(string[] args)
        {
            // Sara Dafi
            // SDI 1912 Section 01
            // Code Exercise 01: Creating Output

            //Prints "Sara Dafi" to the Console
            Console.WriteLine("Sara Dafi");

            //Prints "Mobile Development Bachelor's Degree Program" to the Console
            Console.WriteLine("Mobile Development Bachelor's Degree Program");

            //Prints "I want to develop apps that can potentially be used by the masses" to the Console
            Console.WriteLine("I want to develop apps that can potentially be used by the masses");

           
            

           


        }
    }
}
//