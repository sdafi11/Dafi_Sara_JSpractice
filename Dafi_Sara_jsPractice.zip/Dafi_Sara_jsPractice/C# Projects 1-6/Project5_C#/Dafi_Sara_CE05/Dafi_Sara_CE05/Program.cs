﻿using System;

namespace Dafi_Sara_CE05
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sara Dafi
            //Scalable Data Infrastructures
            //C201912-01
            //Code Exercise 05-Create a Validation Method
            //12/09/2019

            //Create a user input so that the user can enter a number
            //number is books you own
            Console.WriteLine("Today, we are going to calculate how much your outfit costs.\r\nPlease enter the cost of the shoes you are wearing.");

            //Capture the user's response
            string shoeCostString = Console.ReadLine();

            //Declare a variable to hold the converted value
            double shoeCostNum;

            //Validate the user is tping in a valid number using while loop
            while(!double.TryParse(shoeCostString, out shoeCostNum))
            {
                //Alert the user to the error
                Console.WriteLine("Please only type in numbers and do not leave blank!\r\nWhat is the cost of the shoe you are wearing?");

                //Re-capture the user's response in the same variable as before
                shoeCostString = Console.ReadLine();


            }
                
           

            //Tell the user we got the shoe cost and tell them next step
            Console.WriteLine("Thank you! Now please enter the cost of the clothing you are wearing.");

            //Caputre the user's response
            string clothingCostString = Console.ReadLine();

            //Declare a variable to hold the converted value
            double clothingCostNum;

            //Validate the user is typing in a valid number using while loop
            while (!double.TryParse(clothingCostString,out clothingCostNum))
            {

                //Alert the user to the error
                Console.WriteLine("Please only type in number and do not leave blank!\r\nWhat is the cost of the clothing you are wearing?");

                //Re-capture the user's response in the same varialbe as before
                clothingCostString = Console.ReadLine();

            }

            //Tell the user the next step
            Console.WriteLine("Thank you! Now, here's the total cost of the entire outfit you are wearing!");

            //Create a function for total cost
            //Function call and save returned value
            double totalCost = CalcOutfitCost(shoeCostNum, clothingCostNum);

            //Final Output to user
            Console.WriteLine("The total cost of your outfit is ${0}", totalCost);



        }

        public static double CalcOutfitCost(double s, double c)
        {

            //calculate the total cost
            double totalCost = s + c;

            //return total cost value to the Main
            return totalCost;

           

        }






    }
}
