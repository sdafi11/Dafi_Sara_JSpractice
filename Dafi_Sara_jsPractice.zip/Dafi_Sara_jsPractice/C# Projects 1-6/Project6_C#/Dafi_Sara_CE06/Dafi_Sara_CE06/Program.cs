﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
    

namespace Dafi_Sara_CE06
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sara Dafi
            //Scalable Data Infrastructures
            //C201912-01
            //Code Exercise 06-Lists
            //12/12/2019


            //Create a string list
            List<string> mindsetBooks = new List<string>() { "Think & Grow Rich", "The Power of Habit", "The Power of Mindset", "Emotional Intelligence", "Outstanding Mindset" };

            //Explaining to the user what we will be displaying for him/her
            Console.WriteLine("Hello beautiful audience! I got some cool info to share with you!");

            Console.WriteLine("Do you want to get in the right mindset?!\r\nThen, these books are certainly for you!");


            //Create a for loop to cycle through 
            for (int i=0; i<mindsetBooks.Count; i++)
            {
                //This will loop for each element in this list
                
                Console.WriteLine("{0}", mindsetBooks[i]);


            }


            //Create the second string list
            List<string> christmasMovies = new List<string>() { "Christmas with Holly", "Let It Snow", "The Most Wonderful Time Of The Year", "One Starry Christmas", "The Heart of Christmas", "Enchanted Christmas", "A Christmas Melody"};

            //Explaininng to the user what we will be sharing with him/her
            Console.WriteLine("Also, If you love Christmas vibes, let me share with you my best slection for Christmas movies!");

            //Create a for loop to cycle through
            for (int i=0; i<christmasMovies.Count; i++)
            {
                //This will loop for each element in this list
                Console.WriteLine("{0}", christmasMovies[i]);

            }

            //Thanking the audience for reading
            Console.WriteLine("Many thanks & happy holidays!");


























        }
    }
}
