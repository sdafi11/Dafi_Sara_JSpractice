﻿using System;

namespace Dafi_Sara_CE03
{
    class Program
    {
        static void Main(string[] args)
        {

            // Sara Dafi
            // Scalable Data Infrastructures
            // C201912 01
            // Code Exercise 03-Create a conditional



            //Ask the user if he/she is in Mobile Developement, Web Developement, or Undecided
            string degreeQuestion = "Hello, Are you in mobile, web, or undecided? if mobile type 1, if web type 2 or if undecided type 3.";
            Console.WriteLine(degreeQuestion);

            //Capture the user's response and store it in a string variable
            string chosenSelection = Console.ReadLine();

            //Convert to a number datatype
            int chosenDegree = int.Parse(chosenSelection);



            //Create a conditional for every selection
            //chosenDegree "1" (mobile): "Amazing choice! If your dream is to create applications that can potentially be used by the masses then this selection is your best bet. Make sure you enjoy the process!"
            //chosenDegree Web "2"(web): "Great selection! The business world is now shifting gears and moving from the brick and mortar business model to the online platform (websites). This is a great opportunity for you to showcase you web development skills and prove your talents!"
            //chosenDegree Undecided "3" (undecided):"That is ok! Do your research and pursue what will make you satisfied and joyful. Nothing is easy, but the challenging process of your chosen career must be enjoyable for you in order to proceed successfully."

         
           
            if (chosenDegree==1)
            {
                Console.WriteLine("Amazing choice! If your dream is to create applications that can potentially be used by the masses then this selection is your best bet. Make sure you enjoy the process!");

            }else if (chosenDegree==2)
            {
                Console.WriteLine("Great selection! The business world is now shifting gears and moving from the brick and mortar business model to the online platform (websites).This is a great opportunity for you to showcase you web development skills and prove your talents!");

            }else {

                Console.WriteLine("That is ok! Do your research and pursue what will make you satisfied and joyful. Nothing is easy, but the challenging process of your chosen career must be enjoyable for you in order to proceed successfully.");

            }










        }
    }
}
