﻿using System;

namespace Dafi_Sara_CE02
{
    class Program
    {
        static void Main(string[] args)
        {
            //declare the first string variable--first question 
            string firstQuestion = "Have seen a good movie lately?";
            //print the first question
            Console.WriteLine(firstQuestion);
            //Get input from the user
            string firstAnswer = Console.ReadLine();

            //declare the second string variable--second question
            string secondQuestion = "What is its name?";
            //print the second question
            Console.WriteLine(secondQuestion);
            //Get input from the user
            string secondAnswer = Console.ReadLine();

            //declare the third string variable --thirst question
            string thirdQuestion = "What is it about?";
            //print the third question
            Console.WriteLine(thirdQuestion);
            //Get input from the user
            string thirdAnswer = Console.ReadLine();

            //declare an integer question
            string integerQuestion = "How many movies do you watch monthly?";
            //print the integer question
            Console.WriteLine(integerQuestion);
            //Get input from the user
            int fourthAnswer = Convert.ToInt32(Console.ReadLine());


            //declare a boolean question
            string booleanOne = "Do you like romantic movies? yes or no?";
            //print the question
            Console.WriteLine(booleanOne);
            //Get input from the user
            string answerOne = Console.ReadLine();

            //Conditional to get a boolean answer
            if (answerOne == "yes")
            {
                Console.WriteLine("Cool!");
            }
            else if (answerOne == "no")
            {
                Console.WriteLine("Totally fine!");
            }
            else
            {
                Console.WriteLine("Yes/No please.");
            }

            //declare a boolean question
            string booleanTwo = "Do you like cartoon movies? yes or no?";
            //print the question
            Console.WriteLine(booleanTwo);
            //Get input from the user
            string answerTwo = Console.ReadLine();

            //Conditional to get a boolean answer
            if (answerTwo == "yes")
            {
                Console.WriteLine("Cool!");
            }
            else if (answerTwo == "no")
            {
                Console.WriteLine("Totally fine!");
            }
            else
            {
                Console.WriteLine("Yes/No please.");
            }

            








        }
    }
}
