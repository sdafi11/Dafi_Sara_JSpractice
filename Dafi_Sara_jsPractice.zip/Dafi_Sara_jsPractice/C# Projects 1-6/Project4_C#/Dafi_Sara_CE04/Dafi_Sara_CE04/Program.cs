﻿using System;

namespace Dafi_Sara_CE04
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sara Dafi
            //Scalable Data Infrastructures
            //C201912-01
            //Code Exercise 04-Loops
            //12/05/2019


            //1-Ask the user to enter an item that they need to wash, such as a glass or a towel.
            string introQuestion = "Hello! We are here to help you!\r\nWhat do you need to wash? A glass, a towel, or what exactly? please type your answer.";
            //Display the question to the user
            Console.WriteLine(introQuestion);
            //Catch the user's response
            string introAnswer = Console.ReadLine();



            //2-Ask the user to enter how many of those items they have to wash
            string numQuestion = "Please enter the number of how many of those you have to wash.";
            //Display the question to the user
            Console.WriteLine(numQuestion);
            //Catch the user's response
            int numAnswer = Convert.ToInt32(Console.ReadLine());




            //3-Create a loop that will run as many times as it needs to in order to wash each item of the user

            //For loops
            //for (variable to change;Test;increment of change){}
            //We will user for loop because the user will enter a specific number that we can run the loop for


            //What is the least number of items to be washed
            //the user wouldn't type an item if nothing needs to be washed. Threfore the least number of items(numThings)to be washed is 1.

            for (int i=1; i<=numAnswer; i++ ) {

                Console.WriteLine(i + "" + introAnswer+"(s)" + ""+ " has been washed");


            }

            Console.WriteLine("Done!");






        }
    }
}
