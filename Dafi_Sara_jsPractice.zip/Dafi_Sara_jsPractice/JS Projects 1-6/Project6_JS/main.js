//Create a string list
let mindsetBooks = ["Think & Grow Rich", "The Power of Habit", "The Power of Mindset", "Emotional Intelligence", "Outstanding Mindset"];

//Explaining to the user what we will be displaying for him/her
console.log("Hello beautiful audience! I got some cool info to share with you!");
console.log("Do you want to get in the right mindset?!\r\nThen, these books are certainly for you!");


//Create a for loop to cycle through
for (i=0; i<mindsetBooks.length; i++)
{
    //This will loop for each element in this list

    console.log(mindsetBooks[i]);


}


//Create the second string list
let christmasMovies = ["Christmas with Holly", "Let It Snow", "The Most Wonderful Time Of The Year", "One Starry Christmas", "The Heart of Christmas", "Enchanted Christmas", "A Christmas Melody"];

//Explaininng to the user what we will be sharing with him/her
console.log("Also, If you love Christmas vibes, let me share with you my best slection for Christmas movies!");

//Create a for loop to cycle through
for ( i=0; i<christmasMovies.length; i++)
{
    //This will loop for each element in this list
    console.log(christmasMovies[i]);

}

//Thanking the audience for reading
console.log("Many thanks & happy holidays!");