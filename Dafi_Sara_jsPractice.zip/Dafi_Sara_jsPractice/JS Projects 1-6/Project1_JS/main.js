//Prints "Sara Dafi" to the Console
console.log("Sara Dafi")

//Prints "Mobile Development Bachelor's Degree Program" to the Console
console.log("Mobile Development Bachelor's Degree Program");

//Prints "I want to develop apps that can potentially be used by the masses" to the Console
console.log("I want to develop apps that can potentially be used by the masses");