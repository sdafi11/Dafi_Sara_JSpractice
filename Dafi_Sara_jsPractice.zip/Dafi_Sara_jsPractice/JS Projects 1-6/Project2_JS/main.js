//get input from user about a good movie
let movie = prompt("Have seen a good movie lately?");


//get input from user about name of movie
let name = prompt("What is its name?");

//get input from user about what is the movie about
let about = prompt("What is it about?")

//get input from user about how many movies he/she watches monthly
let movieNum = Number(prompt("How many movies do you watch monthly"));


//Get input from the user if he/she likes romantic movies
let romantic = prompt("Do you like romantic movies? yes or no?");
if (romantic == "yes"){
    console.log("Cool!")
}else if (romantic == "no"){
    console.log("Totally fine!")
}else{
    console.log("yes/no please!");
}

//Get input from the user if he/she likes romantic movies
let cartoonMovie = prompt("Do you like cartoon movies? yes or no?");
if (cartoonMovie == "yes"){
    console.log("Cool!")
}else if (cartoonMovie == "no"){
    console.log("Totally fine!")
}else{
    console.log("yes/no please!");
}






