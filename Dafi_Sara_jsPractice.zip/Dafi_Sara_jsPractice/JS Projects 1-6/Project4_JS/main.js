//Sara Dafi
//Scalable Data Infrastructures
//C201912-01
//Code Exercise 04-Loops
//12/05/2019


//1-Ask the user to enter an item that they need to wash, such as a glass or a towel.
let itemToWash = prompt("Hello! We are here to help you!\r\nWhat do you need to wash? A glass, a towel, or what exactly? please type your answer.");




//2-Ask the user to enter how many of those items they have to wash
let itemNumber = Number(prompt("Please enter the number of how many of those you have to wash."));




//3-Create a loop that will run as many times as it needs to in order to wash each item of the user

//For loops
//for (variable to change;Test;increment of change){}
//We will user for loop because the user will enter a specific number that we can run the loop for


//What is the least number of items to be washed
//the user wouldn't type an item if nothing needs to be washed. Threfore the least number of items(numThings)to be washed is 1.

for (i=1; i<=itemNumber; i++ ) {

    console.log(i + " " + itemToWash+"(s)" + ""+ " has been washed");


}

console.log("Done!");
