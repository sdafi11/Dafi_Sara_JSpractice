//Ask the user if he/she is in Mobile Developement, Web Developement, or Undecided
let degreeType = Number(prompt("\"Hello, Are you in mobile, web, or undecided? if mobile type 1, if web type 2 or if undecided type 3.\""));


//Create a conditional for every selection
//chosenDegree "1" (mobile): "Amazing choice! If your dream is to create applications that can potentially be used by the masses then this selection is your best bet. Make sure you enjoy the process!"
//chosenDegree Web "2"(web): "Great selection! The business world is now shifting gears and moving from the brick and mortar business model to the online platform (websites). This is a great opportunity for you to showcase you web development skills and prove your talents!"
//chosenDegree Undecided "3" (undecided):"That is ok! Do your research and pursue what will make you satisfied and joyful. Nothing is easy, but the challenging process of your chosen career must be enjoyable for you in order to proceed successfully."



if (degreeType==1)
{
    console.log("Amazing choice! If your dream is to create applications that can potentially be used by the masses then this selection is your best bet. Make sure you enjoy the process!");

}else if (degreeType==2)
{
    console.log("Great selection! The business world is now shifting gears and moving from the brick and mortar business model to the online platform (websites).This is a great opportunity for you to showcase you web development skills and prove your talents!");

}else {

    console.log("That is ok! Do your research and pursue what will make you satisfied and joyful. Nothing is easy, but the challenging process of your chosen career must be enjoyable for you in order to proceed successfully.");

}
