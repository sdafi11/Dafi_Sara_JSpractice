//Sara Dafi
//Scalable Data Infrastructures
//C201912-01
//Code Exercise 05-Create a Validation Method
//12/09/2019

//Create a user input so that the user can enter a number
//number is books you own
let shoesCost = Number (prompt("Today, we are going to calculate how much your outfit costs.\r\nPlease enter the cost of the shoes you are wearing."));



//Tell the user we got the shoe cost and tell them next step
console.log("Thank you!");

//Capture the user's response
let clothingCost = Number(prompt("Now please enter the cost of the clothing you are wearing."));


//Tell the user the next step
console.log("Thank you! Now, here's the total cost of the entire outfit you are wearing!");

//Create a function for total cost
//Function call and save returned value
let totalCost = clothingCost + shoesCost;

//Final Output to user
console.log("The total cost of your outfit is" + " " + totalCost);




